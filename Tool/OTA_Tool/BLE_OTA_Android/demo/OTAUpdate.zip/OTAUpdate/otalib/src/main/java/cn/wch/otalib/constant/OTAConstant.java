package cn.wch.otalib.constant;

public class OTAConstant {


    //OTA

    public static final String OTA_ServiceUUID="0000fee0-0000-1000-8000-00805f9b34fb";
    public static final String OTA_CharacterUUID="0000fee1-0000-1000-8000-00805f9b34fb";

    //
    public static final String INTENT_KEY_ADDRESS="mac";

}
