package cn.wch.otalib.utils;

import android.util.Log;

public class LogTool {
    public static void d(String message){
        Log.d("BLELOG",message);
    }
}
