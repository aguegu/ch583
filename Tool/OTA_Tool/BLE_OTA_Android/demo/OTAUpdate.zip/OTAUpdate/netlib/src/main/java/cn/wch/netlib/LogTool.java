package cn.wch.netlib;

import android.util.Log;

public class LogTool {
    public static void d(String dstUrl){
        Log.d("BLELOG",dstUrl);
    }
}
