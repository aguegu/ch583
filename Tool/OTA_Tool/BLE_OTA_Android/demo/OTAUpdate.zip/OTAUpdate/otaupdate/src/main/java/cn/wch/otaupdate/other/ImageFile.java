package cn.wch.otaupdate.other;

public enum ImageFile {
    A,
    B
}
