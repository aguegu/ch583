package cn.wch.blelib.exception;

public class BLEPeripheralException extends Exception{
    public BLEPeripheralException(String message) {
        super(message);
    }
}
